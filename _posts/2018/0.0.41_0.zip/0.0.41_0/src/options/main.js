$( document ).ready(function() {
    $("form").submit(function(e){
        save()
        return false
    })
    
    function save() {
        $('#autopayment').val($('#autopaymentCheckbox').is(':checked'))
        $('#fullpagePayment').val($('#fullpagePaymentCheckbox').is(':checked'))

        var data = $('form').serializeArray()
        console.log(data)
        data.unshift({'name': 'buy', 'value': JSON.stringify(itemToJson())})
        chrome.storage.sync.set({setting: data}, function() {
            console.log('data is set to ', data)
            $('#submit').html('SAVED').css('background-color', 'green')
        });
    }

    async function load() {
        chrome.storage.sync.get('setting', function(data) {
            if (!data) {
                return 
            }
            data = data.setting || data
            console.log('data get ', data, data.length)
            for (var i = 0; i < data.length; i ++) {
                var key = data[i]['name']
                var value = data[i]['value']
                $('[name=' + key + ']').val(value)
            }

            if (data && data[0] && data[0].value) {
              JsonToItem(JSON.parse(data[0].value))
            }

            $('#autopaymentCheckbox').prop( "checked", $('#autopayment').val() !== 'false')
            $('#fullpagePaymentCheckbox').prop( "checked", $('#fullpagePayment').val() !== 'false')      
        })
    }

    load()

    initApp()
    $('#login button').click(function() {
        startAuth(true);
    })
    const template = $('addItem')
    $('#addItem').click(function() {
      const entry = template.clone()
      entry.find('button').click(() => {
        entry.remove()
      })
      $('#addItemRoot').append(entry.show())
    })

    const itemToJson = () => {
      return $('#addItemRoot').children().toArray().map((e) => ({
          'name': $(e).find('[name=name]').val(),
          'type': $(e).find('[name=type]').val(),
          'size': $(e).find('[name=size]').val(),
          'size_only': $(e).find('[name=size_only]').is(':checked'),
        })
      )
    }

    const JsonToItem = (json) => {
      return json.forEach(e => {
        $('#addItem').click()
        const root = $('#addItemRoot').children().last()
        root.find('[name=name]').val(e.name)
        root.find('[name=type]').val(e.type)
        root.find('[name=size]').val(e.size)
        root.find('[name=size_only]').prop( "checked", e.size_only );
      });
    }
})


function initApp() {
    // Listen for auth state changes.
    // [START authstatelistener]
    firebase.auth().onAuthStateChanged(async function(user) {
      if (user) {
        // User is signed in.
        var displayName = user.displayName;
        var email = user.email;
        var emailVerified = user.emailVerified;
        var photoURL = user.photoURL;
        var isAnonymous = user.isAnonymous;
        var uid = user.uid;
        var providerData = user.providerData;
        var db = firebase.firestore()
        const settings = {timestampsInSnapshots: true}
        db.settings(settings)

        $('#login').hide()
        var controlRef = db.collection('users').doc('whitelist');
        var whitelist = await controlRef.get()
        if (!whitelist.data().email.includes(email)) {
          $('#root').html('')
          throw ('Auth error')
        }
        $('#root').show()

        chrome.storage.local.get(['device_id'], async function(result) {
          deviceId = result.device_id || makeid()
          var docRef = db.collection('users').doc(deviceId)
          var item = await docRef.get()
          
          if (!result.device_id || !item.exists) {
            docRef.set({
              user: {
                displayName,
                email,
                emailVerified,
                photoURL,
                isAnonymous,
                uid
              },
              device_id: deviceId,
              create_date: firebase.firestore.FieldValue.serverTimestamp(),
            })
            chrome.storage.local.set({'device_id': deviceId}, function() {});
          }
          docRef.update({
            last_login_date: firebase.firestore.FieldValue.serverTimestamp()
          });
          console.log(result, deviceId, email)
        })
      }
    });
  }
  
  /**
   * Start the auth flow and authorizes to Firebase.
   * @param{boolean} interactive True if the OAuth flow should request with an interactive mode.
   */
  function startAuth(interactive) {
    // Request an OAuth token from the Chrome Identity API.
    chrome.identity.getAuthToken({interactive: !!interactive}, function(token) {
      if (chrome.runtime.lastError && !interactive) {
        console.log('It was not possible to get a token programmatically.');
      } else if(chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError);
      } else if (token) {
        // Authorize Firebase with the OAuth Access Token.
        var credential = firebase.auth.GoogleAuthProvider.credential(null, token);
        firebase.auth().signInAndRetrieveDataWithCredential(credential).catch(function(error) {
          // The OAuth token might have been invalidated. Lets' remove it from cache.
          if (error.code === 'auth/invalid-credential') {
            chrome.identity.removeCachedAuthToken({token: token}, function() {
              startAuth(interactive);
            });
          }
        });
      } else {
        console.error('The OAuth Token was null');
      }
    });
  }



// Initialize Firebase
var config = {
    apiKey: "AIzaSyBHzSjm-ch9t6jUFO4PfouR7vPjKo21t-w",
    authDomain: "supreme-bot-2c50b.firebaseapp.com",
    databaseURL: "https://supreme-bot-2c50b.firebaseio.com",
    projectId: "supreme-bot-2c50b",
    storageBucket: "supreme-bot-2c50b.appspot.com",
    messagingSenderId: "605553472455"
};
firebase.initializeApp(config);


function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < 25; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
