function start(settings) {
    const BUY = JSON.parse(settings.filter((r) => r.name == 'buy')[0].value)
    
    var viewCartBeforePay = false // ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'viewCartBeforePay')[0].value)
    var fullpagePayment = ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'fullpagePayment')[0].value)
    var autopayment = ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'autopayment')[0].value)
    
    var billing_name = settings.filter((r) => r.name == 'billing_name')[0].value
    var order_email = settings.filter((r) => r.name == 'order_email')[0].value
    var order_tel = settings.filter((r) => r.name == 'order_tel')[0].value
    var order_address = settings.filter((r) => r.name == 'order_address')[0].value
    var order_address2 = settings.filter((r) => r.name == 'order_address2')[0].value
    var order_billing_zip = settings.filter((r) => r.name == 'order_billing_zip')[0].value
    var order_billing_city = settings.filter((r) => r.name == 'order_billing_city')[0].value
    var order_billing_state = settings.filter((r) => r.name == 'order_billing_state')[0].value
    var order_billing_country = settings.filter((r) => r.name == 'order_billing_country')[0].value
    var delayBuy = settings.filter((r) => r.name == 'delayBuy')[0].value
    
    //Payment info
    var cnb = settings.filter((r) => r.name == 'cnb')[0].value
    var month = settings.filter((r) => r.name == 'month')[0].value
    var year = settings.filter((r) => r.name == 'year')[0].value
    var vval = settings.filter((r) => r.name == 'vval')[0].value
    var cctype = settings.filter((r) => r.name == 'cctype')[0].value

    async function payment() {
        if (!$('#checkout_form').length) {
            console.log('payment page not found')
            return
        }
        /*
        Script to use on checkout screen
        */
        $('input#order_billing_name').attr('value', billing_name);
        const name = billing_name.split(' ')
        $('#cart-address #credit_card_last_name').attr('value', name[1]);
        $('#cart-address #credit_card_first_name').attr('value', name[0]);

        $('input#order_email').attr('value', order_email);
        $('input#order_tel').attr('value', order_tel);
        var full_address = order_address
        if (order_address2) {
            full_address += ' ' + order_address2
        }
        $('input#order_billing_address').attr('value', full_address);
        $('input#bo').attr('value', order_address);
        $('input#oba3').attr('value', order_address2);
        $('input#order_billing_zip').attr('value', order_billing_zip);
        $('input#order_billing_city').attr('value', order_billing_city);
        $('select#order_billing_country').val(order_billing_country);
        if ($('select#order_billing_country').val() !== order_billing_country) {
            $('select#order_billing_country').find('option:contains("'+order_billing_country.toUpperCase()+'")').prop("selected", true);
        }
        $('select#order_billing_state').val(order_billing_state);
        if ($('select#order_billing_state').val() === '') {
            $('select#order_billing_state').val(' ' + order_billing_state); // HACK!!! their option has a space 
        }
        $('#order_billing_address_3').val(order_billing_state); // Europe

        $('input#nnaerb').attr('value', cnb);
        $('input#cnb').attr('value', cnb);
        $('input#nnaerb').keyup()
        $('input#cnb').keyup()

        $('select#credit_card_month').val(month);
        $('select#credit_card_year').val(year);
        $('input#orcer').attr('value', vval);
        $('input#vval').attr('value', vval);

    
        $('.iCheck-helper').attr('checked', 'checked');
        $('.checkbox').attr('checked', 'checked');
        $('#order_terms').attr('checked', 'checked');

        $('form#checkout_form').attr('data-verified', 'done');
        
        $('#credit_card_type').find('option:contains("'+ cctype + '")').prop("selected", true);

        if (autopayment) {
            await timeout(delayBuy * 1000)
            $('#checkout_form').submit()
        }
    }

    function timeout(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    payment()
}


if (!window.settingsJSON || !window.settingsJSON['setting']) {
    alert('请先去设置并保存, 然后重新打开此页面')
} else {
    start(window.settingsJSON['setting'])
}

