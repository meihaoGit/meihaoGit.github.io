let state = ''
chrome.extension.sendMessage({}, function(response) {
	checkHomeShopPage()
	checkShopPage()
	checkPaymentPage()
});

function checkHomeShopPage() {
	var readyStateCheckInterval = setInterval(function() {
		if (window.location.href === 'https://www.supremenewyork.com/shop' ||
			window.location.href === 'http://www.supremenewyork.com/shop'
		) {
			clearInterval(readyStateCheckInterval);
			chrome.storage.sync.get('setting', function (settings) {
				start(settings, 'shophome')
			})
		}
	}, 100);
}

function checkShopPage() {
	var readyStateCheckInterval = setInterval(function() {
		if (window.location.href === 'https://www.supremenewyork.com/shop/all?run' ||
			window.location.href === 'http://www.supremenewyork.com/shop/all?run' ||
			window.location.href === 'https://www.supremenewyork.com/shop/new?run' || 
			window.location.href === 'http://www.supremenewyork.com/shop/new?run'
		) {
			clearInterval(readyStateCheckInterval);
			chrome.storage.sync.get('setting', function (settings) {
				start(settings, 'shop')
			})
		}
	}, 100);
}

function checkPaymentPage() {
	var readyStateCheckInterval = setInterval(function() {
		if (window.location.href === 'https://www.supremenewyork.com/checkout?run' ||
			window.location.href === 'http://www.supremenewyork.com/checkout?run'
		) {
			clearInterval(readyStateCheckInterval);
			chrome.storage.sync.get('setting', function (settings) {
				start(settings, 'payment')
			})
		}
	}, 100);
}


async function start(settings, page) {
	function injectScript(file, node) {
		var th = document.getElementsByTagName(node)[0];
		var s = document.createElement('script');
		s.setAttribute('type', 'text/javascript');
		s.setAttribute('src', file);
		th.appendChild(s);
	}

	var actualCode = `
	window.settingsJSON = ${ JSON.stringify(settings) };
	`;
	var script = document.createElement('script');
	script.textContent = actualCode;
	(document.head||document.documentElement).appendChild(script);
	script.remove();
	injectScript( chrome.extension.getURL('./js/console-log-viewer.js?align=bottom'), 'body');


	var script = document.createElement('script');
	script.textContent = actualCode;
	(document.head||document.documentElement).appendChild(script);
	script.remove();
	injectScript( chrome.extension.getURL('./js/lodash.core.js'), 'body');

	var script = document.createElement('script');
	script.textContent = actualCode;
	(document.head||document.documentElement).appendChild(script);
	script.remove();

	let url;
	if (page === 'shop') {
		url = './src/inject/my_file.js'
	} else if (page === 'payment') {
		url = './src/inject/payment.js'
	} else if (page === 'shophome') {
		url = './src/inject/shophome.js'
	}
	injectScript( chrome.extension.getURL(url), 'body');
}
