function start(settings) {

    const BUY = JSON.parse(settings.filter((r) => r.name == 'buy')[0].value)
    
    var viewCartBeforePay = false // ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'viewCartBeforePay')[0].value)
    var fullpagePayment = window.location.protocol === 'http:' // ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'fullpagePayment')[0].value)
    var autopayment = ['True', 'true', true, 't'].includes(settings.filter((r) => r.name == 'autopayment')[0].value)
    
    var billing_name = settings.filter((r) => r.name == 'billing_name')[0].value
    var order_email = settings.filter((r) => r.name == 'order_email')[0].value
    var order_tel = settings.filter((r) => r.name == 'order_tel')[0].value
    var order_address = settings.filter((r) => r.name == 'order_address')[0].value
    var order_address2 = settings.filter((r) => r.name == 'order_address2')[0].value
    var order_billing_zip = settings.filter((r) => r.name == 'order_billing_zip')[0].value
    var order_billing_city = settings.filter((r) => r.name == 'order_billing_city')[0].value
    var order_billing_state = settings.filter((r) => r.name == 'order_billing_state')[0].value
    var order_billing_country = settings.filter((r) => r.name == 'order_billing_country')[0].value
    var delayBuy = settings.filter((r) => r.name == 'delayBuy')[0].value

    //Payment info
    var cnb = settings.filter((r) => r.name == 'cnb')[0].value
    var month = settings.filter((r) => r.name == 'month')[0].value
    var year = settings.filter((r) => r.name == 'year')[0].value
    var vval = settings.filter((r) => r.name == 'vval')[0].value
    var cctype = settings.filter((r) => r.name == 'cctype')[0].value
    

    //--------------CODE START----------------

    async function cacheGet(link) {
        let content = sessionStorage.getItem(link)
        if (!content) {
            content = await $.get(link)
            sessionStorage.setItem(link, content)
        }
        return content
    }
    
    let mainContent
    let counter = 0
    setInterval(async () => {
        const content = await $.get(window.location.href)

        if (!mainContent) {
            mainContent = content
        } else if (content != mainContent) {
            const virtualDOM1 = document.implementation.createHTMLDocument('virtual');
            const virtualDOM2 = document.implementation.createHTMLDocument('virtual');
            const newcontent = $($.parseHTML(content, virtualDOM1), virtualDOM1)
            const oldContent = $($.parseHTML(mainContent, virtualDOM2), virtualDOM2)
            const hrefs1 = getItemsLink(oldContent).sort()
            const hrefs2 = getItemsLink(newcontent).sort()
            if (!_.isEqual(hrefs1, hrefs2)) {
                console.log('Website new item update detected.')
                init(hrefs2)
            } else {
                console.debug('Website updated but no new item update detected')
            }
        }
        mainContent = content

        counter ++
        coms.html(`
            <div style="
                position: fixed;
                top: 10px;
                left: 10px;
                font-size: 20px;
                font-family: bold;
            ">
            倚天剑 - Supreme Bot
            <br>
            背景自动刷新中 ${counter}
            </div>
        `)
    }, 1000)

    const virtualDOM = document.implementation.createHTMLDocument('virtual');
    const root = $('#header')
    const coms = $('<div/>')
    $('body').append(coms)

    // supreme
    const shouldBuyItem = function (item) {
        for (var i = 0; i < BUY.length; i ++) {
            const req = BUY[i]
            if (item.name.toLowerCase().includes(req.name.toLowerCase()) &&
                (!req.type || item.type.toLowerCase().includes(req.type.toLowerCase()))) {
                    return req
                }
        }
        return false
    }
    function getItemsLink(ele) {
        if (!ele) {
            ele = $('body')
        }
        const a = ele.find('.inner-article a')
        return a.toArray().map(element => {
            return element.href
        });
    }
    async function formSubmit(form) {
        return new Promise((resolve, reject) => {
            form.submit(function(event) {
                $.ajax({
                    data: $(this).serialize(),
                    type: $(this).attr('method'),
                    url: $(this).attr('action'),
                    success: resolve,
                    error: reject,
                });
                event.preventDefault();
            });
            form.submit()
        })
    }

    async function linkToName(link) {
        const content = await cacheGet(link)
        const html = $($.parseHTML(content, virtualDOM), virtualDOM)
        let selector = html.find('select[name=s] option')
        if (!selector.length) {
            selector = html.find('#size') // EU
        }
        const size = selector.toArray().map((r)=> $(r).html())
        return {
            name: html.find('#details h1').html(),
            type: html.find('[itemprop="model"]').html(),
            soldout: html.find('#add-remove-buttons .sold-out').length > 0,
            size: size,
            link: link,
            html: html,
        }
    }
    
    function timeout(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    var addToCart = async function(item, req) {
        await root.html(item.html).promise()
        const form = root.find('#cart-addf')
        const soldout = root.find('#add-remove-buttons').find('.sold-out')
        const incart = root.find('#cart-remove').find('.in-cart')
        if (incart.length) {
            console.warn('Item is in cart already.', item.name)
        } else if (soldout.length) {
            console.warn('Item is either sold out or limited 1 item per customer.', item.name)
        }  else if (!form.length) {
            console.warn('Couldnt find buy action function for item.', item.name)
        } else {
            let selected
            if (req.size) {
                // const option = form.find("option:contains('"+size+"'):first").attr('selected',true);
                let selector = form.find('#s')
                if (!selector.length) {
                    selector = form.find('#size') // EU
                }
                const sizes = selector.children().toArray().map((e)=> $(e).html())
                const req_sizes = req.size.split(',')
                for (let i = 0; i < sizes.length; i++) {
                    for (let n = 0; n < req_sizes.length; n++) {
                        if (sizes[i].toLowerCase().trim() === req_sizes[n].toLowerCase().trim()) {
                            selected = form.find("option:contains('"+sizes[i]+"'):first").attr('selected',true);
                        }
                    }
                }

                console.log(
                    item.name,
                    'Total options:',
                    form.find("option").toArray().map((e) => $(e).html()),
                    '   Request size:',
                    req.size,
                    '   Selecting:',
                    selected,
                )
            }
            if (req.size_only && !selected) {
                console.warn('No item for this size. skipping', item.name)
                return;
            }
            const submit = form.find('[type="submit"]')
            if (!submit.length) {
                console.warn('Couldnt find add cart button for item', item.name)
            } else {
                try {
                    await formSubmit(form)
                } catch {}
                if ($(soldout.selector).length) {
                    console.warn('Limited 1 item per customer.', item.name)
                }
            }
        }
        await root.html('')
    }

    var init = async function (links=getItemsLink()) {
        var promises = links.map(async function(l) {
            return await linkToName(l)
        })
        const detail = {}
        var linksToName = await Promise.all(promises)
        for (var i = 0; i < links.length; i ++) {
            const item = linksToName[i]
            if (!detail[item.name]) {
                detail[item.name] = []
            }
            detail[item.name].push(item)
        }
        
        for (var itemName in detail) {
            for (var itemType in detail[itemName]) {
                const item = detail[itemName][itemType]
                if (item.soldout) {
                    continue
                }

                var req = shouldBuyItem(item)
                if (req) {
                    await addToCart(item, req)
                }
            }
        }
        console.log('Added all items, Sending to cart or payment page.')
        await sendToPayment()
    }
    
    const sendToPayment = async function() {
        const url = window.location.protocol + '//www.supremenewyork.com/shop/cart'
        const urlContent = await $.get(url)
        const content = $($.parseHTML(urlContent))
        content.find('#cart-footer').html(
            '<button class="button checkout" href="#" onclick="readyToPay()"> Pay </button>')
        root.html(content)
        const itemsInCart = root.find('#cart-body').find('.cart-image').length
        if (!itemsInCart) {
            console.log('No item in cart. waiting for webpage update refresh.')
            return
        }

        //remove out of stock items
        try {
            var promises = []
            out_of_stock = root.find('#cart-body').find('.out_of_stock form')
            for (var i = 0; i < out_of_stock.length; i ++) {
                promises.append(formSubmit(out_of_stock))
            }
            await Promise.all(promises)
        } catch {}

        if (!viewCartBeforePay) {
            window.readyToPay()
        }
    }   
    
    window.readyToPay  = async function() {
        const url = location.protocol + '//www.supremenewyork.com/checkout?run'
        if (fullpagePayment) {
            window.location.href = url
            return;
        }
        let urlContent
        try {
            urlContent = await $.get(url)
        } catch {
            console.error('Unable to load checkout page. Send back to cart page')
            sendToPayment()
            return;
        }
        const content = $($.parseHTML(urlContent))
        root.html(content)
        payment()
    }
    
    var removeAllInCart = async function() {
        $('.cart-remove form').submit()
    }
    
    async function payment() {
        if (!$('#checkout_form').length) {
            console.log('payment page not found')
            return
        }
        /*
        Script to use on checkout screen
        */
        $('input#order_billing_name').attr('value', billing_name);
        const name = billing_name.split(' ')
        $('#cart-address #credit_card_last_name').attr('value', name[1]);
        $('#cart-address #credit_card_first_name').attr('value', name[0]);

        $('input#order_email').attr('value', order_email);
        $('input#order_tel').attr('value', order_tel);
        var full_address = order_address
        if (order_address2) {
            full_address += ' ' + order_address2
        }
        $('input#order_billing_address').attr('value', full_address);
        $('input#bo').attr('value', order_address);
        $('input#oba3').attr('value', order_address2);
        $('input#order_billing_zip').attr('value', order_billing_zip);
        $('input#order_billing_city').attr('value', order_billing_city);
        $('select#order_billing_country').val(order_billing_country);
        if ($('select#order_billing_country').val() !== order_billing_country) {
            $('select#order_billing_country').find('option:contains("'+order_billing_country.toUpperCase()+'")').prop("selected", true);
        }
        $('select#order_billing_state').val(order_billing_state);
        if ($('select#order_billing_state').val() === '') {
            $('select#order_billing_state').val(' ' + order_billing_state); // HACK!!! their option has a space 
        }
        $('#order_billing_address_3').val(order_billing_state); // Europe

        $('input#nnaerb').attr('value', cnb);
        $('input#cnb').attr('value', cnb);
        $('input#nnaerb').keyup()
        $('input#cnb').keyup()

        $('select#credit_card_month').val(month);
        $('select#credit_card_year').val(year);
        $('input#orcer').attr('value', vval);
        $('input#vval').attr('value', vval);

    
        $('.iCheck-helper').attr('checked', 'checked');
        $('.checkbox').attr('checked', 'checked');
        $('#order_terms').attr('checked', 'checked');

        $('form#checkout_form').attr('data-verified', 'done');
        
        $('#credit_card_type').find('option:contains("'+ cctype + '")').prop("selected", true);

        if (autopayment) {
            await timeout(delayBuy * 1000)
            $('#checkout_form').submit()
        }
    }

    init()
}

if (!window.settingsJSON || !window.settingsJSON['setting']) {
    alert('请先去设置并保存, 然后重新打开此页面')
} else {
    start(window.settingsJSON['setting'])
}
