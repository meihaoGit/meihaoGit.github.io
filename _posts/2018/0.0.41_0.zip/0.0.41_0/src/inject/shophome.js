const url = window.location.protocol + '//www.supremenewyork.com/shop/all?run'
location.href = url
